var classassignment8_1_1_mathematical_operations =
[
    [ "addition", "classassignment8_1_1_mathematical_operations.html#a9b223b9c46b25a419b593b158c3bef38", null ],
    [ "division", "classassignment8_1_1_mathematical_operations.html#a703afb87c0bb7b8b775d8df3af6e528e", null ],
    [ "greaterThan", "classassignment8_1_1_mathematical_operations.html#aa81d9472a5dd119b3d710b403753ac04", null ],
    [ "inverseDivision", "classassignment8_1_1_mathematical_operations.html#a7e6df60cee2033096f9d5b48a943be11", null ],
    [ "multiplication", "classassignment8_1_1_mathematical_operations.html#a5460717b7f46bf33b95b31e8aa8c2a28", null ],
    [ "negation", "classassignment8_1_1_mathematical_operations.html#a0969c28ff785765b1f60b2dc6713d048", null ],
    [ "power", "classassignment8_1_1_mathematical_operations.html#a3f2f0a5f029dc9de071c884f01f20031", null ],
    [ "remainder", "classassignment8_1_1_mathematical_operations.html#ad921ad2cbff5e5080ba71561ca6162a0", null ],
    [ "subtraction", "classassignment8_1_1_mathematical_operations.html#a4b7d4c9a7fda447ebfb0b0d3b67f636c", null ],
    [ "unaryMinus", "classassignment8_1_1_mathematical_operations.html#a5279c411cdb7fe9b47b340d05ca62f22", null ],
    [ "unaryPlus", "classassignment8_1_1_mathematical_operations.html#ae2b388f82eaf287e2226f5243be0ef1a", null ]
];