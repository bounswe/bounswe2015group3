var searchData=
[
  ['unaryminus',['unaryMinus',['../classassignment8_1_1_mathematical_operations.html#a5279c411cdb7fe9b47b340d05ca62f22',1,'assignment8::MathematicalOperations']]],
  ['unaryplus',['unaryPlus',['../classassignment8_1_1_mathematical_operations.html#ae2b388f82eaf287e2226f5243be0ef1a',1,'assignment8::MathematicalOperations']]]
];
