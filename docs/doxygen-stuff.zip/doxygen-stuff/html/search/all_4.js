var searchData=
[
  ['power',['power',['../classassignment8_1_1_mathematical_operations.html#a3f2f0a5f029dc9de071c884f01f20031',1,'assignment8::MathematicalOperations']]]
];
