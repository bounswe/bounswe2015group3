var searchData=
[
  ['greaterthan',['greaterThan',['../classassignment8_1_1_mathematical_operations.html#aa81d9472a5dd119b3d710b403753ac04',1,'assignment8::MathematicalOperations']]]
];
