var annotated =
[
    [ "assignment8", null, [
      [ "MathematicalOperations", "classassignment8_1_1_mathematical_operations.html", "classassignment8_1_1_mathematical_operations" ],
      [ "TestMathematicalOperations", "classassignment8_1_1_test_mathematical_operations.html", "classassignment8_1_1_test_mathematical_operations" ]
    ] ]
];