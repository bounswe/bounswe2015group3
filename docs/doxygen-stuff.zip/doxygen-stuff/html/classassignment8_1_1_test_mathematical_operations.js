var classassignment8_1_1_test_mathematical_operations =
[
    [ "testAddition", "classassignment8_1_1_test_mathematical_operations.html#a22213a2f601221232b5eb0413c11ca85", null ],
    [ "testGreaterThan", "classassignment8_1_1_test_mathematical_operations.html#a5346cb33c7969f98fc0cabeef5a395bc", null ],
    [ "testInverseDivision", "classassignment8_1_1_test_mathematical_operations.html#a08cf93173e859a2f9834682c75947c03", null ],
    [ "testMultiplication", "classassignment8_1_1_test_mathematical_operations.html#aebf117c9613b627d8681279d1d109945", null ],
    [ "testNegation", "classassignment8_1_1_test_mathematical_operations.html#a53a6620a87dcc7f5d43514c9ee0f0be8", null ],
    [ "testPower", "classassignment8_1_1_test_mathematical_operations.html#a230fe816ea25f43834c71ce239dabc9d", null ],
    [ "testRemainder", "classassignment8_1_1_test_mathematical_operations.html#a7a79ee79b237293b8a1e3a17601a6932", null ],
    [ "testSubtraction", "classassignment8_1_1_test_mathematical_operations.html#ad250d289f5fe75d54deefce6ad96d1dc", null ],
    [ "testUnaryMinus", "classassignment8_1_1_test_mathematical_operations.html#a11a8b2e54f94093dbbb631071f94b86a", null ],
    [ "testUnaryPlus", "classassignment8_1_1_test_mathematical_operations.html#ad1e7b40a849d68cabb5b628f3e32b995", null ]
];